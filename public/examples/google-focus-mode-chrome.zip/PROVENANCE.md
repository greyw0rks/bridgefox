# Source

Google Chrome extension sample, packaged for BridgeFox input testing.

Source: https://github.com/GoogleChrome/chrome-extensions-samples/tree/b7d8bebb00bb11191126c6abbe471ec5f79c4feb/functional-samples/tutorial.focus-mode
Revision: b7d8bebb00bb11191126c6abbe471ec5f79c4feb

Original source files are unchanged. The repository's LICENSE and this provenance note are included. No Otari calls or Firefox runtime tests were performed while packaging.
